package id.allana.githubapp_bfaa.data.base

import androidx.lifecycle.ViewModel

open class BaseViewModelImpl: ViewModel(), BaseContract.BaseViewModel