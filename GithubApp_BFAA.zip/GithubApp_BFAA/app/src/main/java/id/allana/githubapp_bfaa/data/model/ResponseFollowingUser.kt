package id.allana.githubapp_bfaa.data.model

import com.google.gson.annotations.SerializedName

data class ResponseFollowingUser(

	@field:SerializedName("ResponseFollowingUser")
	val responseFollowingUser: List<ItemsItem>? = null

)
