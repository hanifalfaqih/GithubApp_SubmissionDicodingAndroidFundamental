package id.allana.githubapp_bfaa.data.model

import com.google.gson.annotations.SerializedName

data class ResponseFollowerUser(

	@field:SerializedName("ResponseFollowerUser")
	val responseFollowerUser: List<ItemsItem>? = null
)


